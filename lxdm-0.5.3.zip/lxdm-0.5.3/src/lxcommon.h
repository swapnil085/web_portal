#ifndef _LXCOMMON_H_
#define _LXCOMMON_H_

#define VCONFIG_FILE 		"/var/lib/lxdm/lxdm.conf"

#endif /*_LXCOMMON_H_*/

